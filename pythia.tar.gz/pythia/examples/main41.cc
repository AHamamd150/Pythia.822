
#include "Pythia8/Pythia.h"
#include "Pythia8Plugins/HepMC2.h"

using namespace Pythia8;


int main() {

 int NEVENTS = 100     ;
  HepMC::Pythia8ToHepMC ToHepMC;

  // Specify file where HepMC events will be stored.
  HepMC::IO_GenEvent ascii_io("H.hep", std::ios::out);

  Pythia pythia;
  pythia.readString("Beams:eCM =  12000      ");
  pythia.readString("SoftQCD:all =  on            ");
  pythia.readString("HardQCD:all =  on            ");
  pythia.readString("HardQCD:3parton =  on            ");
  pythia.readString("PhaseSpace:pTHatMin =   2     ");
  pythia.init();
  // Begin event loop. Generate event. Skip if error.
  for (int iEvent = 0; iEvent < NEVENTS; ++iEvent) {
    if (!pythia.next()) continue;
   HepMC::GenEvent* hepmcevt = new HepMC::GenEvent();
    ToHepMC.fill_next_event( pythia, hepmcevt );
     ascii_io << hepmcevt;
     delete hepmcevt;

  }
  pythia.stat();
  return 0;
}
